<?php
/* ============================================================
   Sunrise Hotel - Booking Confirmation
   Receives POST data from booking.html
   Individualization Requirement (digit 9):
     - Late Checkout option (KSh 2,000)
   ============================================================ */

// ---------- 1. Receive submitted values ----------
$fullName   = isset($_POST['fullName']) ? trim($_POST['fullName']) : '';
$idNumber   = isset($_POST['idNumber']) ? trim($_POST['idNumber']) : '';
$email      = isset($_POST['email']) ? trim($_POST['email']) : '';
$phone      = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$checkin    = isset($_POST['checkin']) ? $_POST['checkin'] : '';
$nights     = isset($_POST['nights']) ? (int)$_POST['nights'] : 0;
$roomType   = isset($_POST['roomType']) ? $_POST['roomType'] : '';
$guests     = isset($_POST['guests']) ? (int)$_POST['guests'] : 0;
$breakfast  = isset($_POST['breakfast']) ? 'Yes' : 'No';
$transfer   = isset($_POST['transfer']) ? 'Yes' : 'No';
$transferTime = isset($_POST['transferTime']) ? $_POST['transferTime'] : '';
$lateCheckout = isset($_POST['lateCheckout']) ? 'Yes' : 'No';

// ---------- 2. Server-side validation ----------
$errors = [];

if ($fullName === '') {
    $errors[] = 'Full name is required.';
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'A valid email address is required.';
}
if (!preg_match('/^\d{10}$/', $phone)) {
    $errors[] = 'Phone number must be exactly 10 digits.';
}
if ($nights < 1 || $nights > 14) {
    $errors[] = 'Number of nights must be between 1 and 14.';
}
if ($guests <= 0) {
    $errors[] = 'Number of guests must be greater than zero.';
}
if (!in_array($roomType, ['Single', 'Double', 'Family'])) {
    $errors[] = 'Please select a valid room type.';
}

// Room capacities
$capacities = ['Single' => 1, 'Double' => 2, 'Family' => 4];
if (isset($capacities[$roomType]) && $guests > $capacities[$roomType]) {
    $errors[] = "Number of guests exceeds capacity for a $roomType room.";
}

// If errors, show them and stop
if (!empty($errors)) {
    echo "<h2 style='color:red;'>Booking Failed</h2><ul>";
    foreach ($errors as $e) {
        echo "<li>" . htmlspecialchars($e) . "</li>";
    }
    echo "</ul><a href='booking.html'>Go back</a>";
    exit;
}

// ---------- 3. Independently calculate the total ----------
$roomRates = [
    'Single' => 3500,
    'Double' => 5000,
    'Family' => 7500
];

$roomCost      = $roomRates[$roomType] * $nights;
$breakfastCost = ($breakfast === 'Yes') ? 700 * $guests * $nights : 0;
$transferCost  = ($transfer === 'Yes') ? 2000 : 0;
$lateCheckoutCost = ($lateCheckout === 'Yes') ? 2000 : 0;  // Individualization (digit 9)
$total         = $roomCost + $breakfastCost + $transferCost + $lateCheckoutCost;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking Confirmation - Sunrise Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>🌅 Sunrise Hotel</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="booking.html">Book a Room</a>
        </nav>
    </header>

    <main class="confirmation">
        <h2>BOOKING CONFIRMED</h2>

        <p><strong>Customer:</strong> <?php echo htmlspecialchars($fullName); ?></p>
        <p><strong>ID/Passport:</strong> <?php echo htmlspecialchars($idNumber); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($phone); ?></p>
        <p><strong>Check-in Date:</strong> <?php echo htmlspecialchars($checkin); ?></p>
        <p><strong>Room:</strong> <?php echo htmlspecialchars($roomType); ?> Room</p>
        <p><strong>Guests:</strong> <?php echo $guests; ?></p>
        <p><strong>Number of Nights:</strong> <?php echo $nights; ?></p>
        <p><strong>Breakfast:</strong> <?php echo $breakfast; ?>
            <?php if ($breakfast === 'Yes') echo " (KSh " . number_format($breakfastCost) . ")"; ?>
        </p>
        <p><strong>Airport Transfer:</strong> <?php echo $transfer; ?>
            <?php if ($transfer === 'Yes') echo " (KSh " . number_format($transferCost) . ")"; ?>
        </p>
        <?php if ($transfer === 'Yes' && $transferTime !== ''): ?>
            <p><strong>Pickup Time:</strong> <?php echo htmlspecialchars($transferTime); ?></p>
        <?php endif; ?>
        <p><strong>Late Checkout:</strong> <?php echo $lateCheckout; ?>
            <?php if ($lateCheckout === 'Yes') echo " (KSh " . number_format($lateCheckoutCost) . ")"; ?>
        </p>

        <hr>
        <p>Room Cost: KSh <?php echo number_format($roomCost); ?></p>
        <p>Breakfast Cost: KSh <?php echo number_format($breakfastCost); ?></p>
        <p>Transfer Cost: KSh <?php echo number_format($transferCost); ?></p>
        <p>Late Checkout Cost: KSh <?php echo number_format($lateCheckoutCost); ?></p>

        <p class="total">TOTAL AMOUNT PAYABLE: KSh <?php echo number_format($total); ?></p>

        <p>Thank you for choosing Sunrise Hotel!</p>
    </main>

    <footer>
        <p>&copy; 2026 Sunrise Hotel. All rights reserved.</p>
    </footer>
</body>
</html>