/* ============================================================
   Sunrise Hotel - Booking System JavaScript
   Author: [Your Name]
   Admission Number: 24519
   Individualization Requirement (digit 9):
     - Add Late Checkout option costing KSh 2,000
   ============================================================ */

// Room rates (per night)
const ROOM_RATES = {
    Single: 3500,
    Double: 5000,
    Family: 7500
};

// Room capacities
const ROOM_CAPACITY = {
    Single: 1,
    Double: 2,
    Family: 4
};

const BREAKFAST_RATE = 700;     // per person per day
const TRANSFER_FEE = 2000;      // flat fee
const LATE_CHECKOUT_FEE = 2000; // Individualization requirement (digit 9)

/* ------------------------------------------------------------
   Function 1: validateBooking()
   Validates the form before submission.
   Returns false if invalid, true if valid.
   ------------------------------------------------------------ */
function validateBooking(event) {
    event.preventDefault(); // stop submission initially

    let isValid = true;
    clearAllErrors();

    // 1. Full name not empty
    const fullName = document.getElementById('fullName').value.trim();
    if (fullName === '') {
        showError('fullName', 'Full name is required.');
        isValid = false;
    }

    // 2. Email valid format
    const email = document.getElementById('email').value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        showError('email', 'Enter a valid email address.');
        isValid = false;
    }

    // 3. Phone exactly 10 digits
    const phone = document.getElementById('phone').value.trim();
    const phonePattern = /^\d{10}$/;
    if (!phonePattern.test(phone)) {
        showError('phone', 'Phone number must be exactly 10 digits.');
        isValid = false;
    }

    // 4. Nights between 1 and 14
    const nights = parseInt(document.getElementById('nights').value);
    if (isNaN(nights) || nights < 1 || nights > 14) {
        showError('nights', 'Number of nights must be between 1 and 14.');
        isValid = false;
    }

    // 5. Guests > 0
    const guests = parseInt(document.getElementById('guests').value);
    if (isNaN(guests) || guests <= 0) {
        showError('guests', 'Number of guests must be greater than zero.');
        isValid = false;
    }

    // 6. Room type selected
    const roomType = document.getElementById('roomType').value;
    if (roomType === '') {
        showError('roomType', 'Please select a room type.');
        isValid = false;
    }

    // 7. Guests must not exceed room capacity
    if (roomType !== '' && guests > ROOM_CAPACITY[roomType]) {
        showError('guests', `Maximum guests for ${roomType} room is ${ROOM_CAPACITY[roomType]}.`);
        isValid = false;
    }

    // If valid, allow actual submission
    if (isValid) {
        document.getElementById('bookingForm').submit();
    }
    return false;
}

/* ------------------------------------------------------------
   Function 2: calculateBill()
   Computes total cost and updates display + summary.
   Includes Late Checkout (individualization requirement).
   ------------------------------------------------------------ */
function calculateBill() {
    const roomType = document.getElementById('roomType').value;
    const nights = parseInt(document.getElementById('nights').value) || 0;
    const guests = parseInt(document.getElementById('guests').value) || 0;
    const breakfast = document.getElementById('breakfast').checked;
    const transfer = document.getElementById('transfer').checked;
    const lateCheckout = document.getElementById('lateCheckout').checked;

    let roomCost = 0;
    if (roomType && ROOM_RATES[roomType]) {
        roomCost = ROOM_RATES[roomType] * nights;
    }

    let breakfastCost = breakfast ? BREAKFAST_RATE * guests * nights : 0;
    let transferCost = transfer ? TRANSFER_FEE : 0;
    let lateCheckoutCost = lateCheckout ? LATE_CHECKOUT_FEE : 0;

    const total = roomCost + breakfastCost + transferCost + lateCheckoutCost;

    // Update total display
    document.getElementById('totalDisplay').textContent =
        'Estimated Total: KSh ' + total.toLocaleString();

    // Update summary
    let summary = '';
    if (roomType) {
        summary += `Room: ${roomType} × ${nights} night(s) = KSh ${roomCost.toLocaleString()}<br>`;
    }
    if (breakfast) {
        summary += `Breakfast: ${guests} guest(s) × ${nights} day(s) = KSh ${breakfastCost.toLocaleString()}<br>`;
    }
    if (transfer) {
        summary += `Airport Transfer: KSh ${transferCost.toLocaleString()}<br>`;
    }
    if (lateCheckout) {
        summary += `Late Checkout: KSh ${lateCheckoutCost.toLocaleString()}<br>`;
    }
    if (summary === '') {
        summary = 'Select room and options to see summary.';
    } else {
        summary += `<strong>Total: KSh ${total.toLocaleString()}</strong>`;
    }
    document.getElementById('summary').innerHTML = summary;
}

/* ------------------------------------------------------------
   Function 3: updateRoomInfo()
   Displays maximum guests when room type is selected.
   ------------------------------------------------------------ */
function updateRoomInfo() {
    const roomType = document.getElementById('roomType').value;
    const info = document.getElementById('roomInfo');

    if (roomType) {
        info.textContent = `Maximum guests allowed: ${ROOM_CAPACITY[roomType]}`;
    } else {
        info.textContent = '';
    }
    calculateBill();
}

/* ------------------------------------------------------------
   Function 4: checkRoomCapacity()
   Warns if guests exceed room capacity.
   ------------------------------------------------------------ */
function checkRoomCapacity() {
    const roomType = document.getElementById('roomType').value;
    const guests = parseInt(document.getElementById('guests').value) || 0;
    const errorDiv = document.getElementById('guestsError');

    if (roomType && guests > ROOM_CAPACITY[roomType]) {
        errorDiv.textContent = `Warning: ${roomType} room allows a maximum of ${ROOM_CAPACITY[roomType]} guest(s).`;
    } else {
        errorDiv.textContent = '';
    }
}

/* ------------------------------------------------------------
   Function 5: toggleTransferOptions()
   Shows/hides transfer time field dynamically.
   ------------------------------------------------------------ */
function toggleTransferOptions() {
    const transfer = document.getElementById('transfer').checked;
    document.getElementById('transferOptions').style.display = transfer ? 'block' : 'none';
}

/* ------------------------------------------------------------
   Helper functions for error handling
   ------------------------------------------------------------ */
function showError(fieldId, message) {
    document.getElementById(fieldId + 'Error').textContent = message;
}

function clearError(fieldId) {
    document.getElementById(fieldId + 'Error').textContent = '';
}

function clearAllErrors() {
    ['fullName', 'email', 'phone', 'nights', 'guests', 'roomType'].forEach(id => {
        document.getElementById(id + 'Error').textContent = '';
    });
}

// Recalculate on page load (in case of pre-filled values)
window.onload = function () {
    calculateBill();
};